wq_data <- read.csv("C:/Users/User/Desktop/ȯ���� �м�������.csv",
                    sep=",", header=T, fileEncoding = "euc-kr")
wq_data1 <- na.omit(wq_data)


## principal component analysis
library(factoextra)
res.pca <- prcomp(wq_data1[1:17], scale = TRUE)
fviz_eig(res.pca)
fviz_pca_var(res.pca,
             col.var = "contrib", # Color by contributions to the PC
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)
round(predict(res.pca), 3)


## correlation analysis
library(ggcorrplot)

corr <- round(cor(wq_data1[1:17], method="spearman"),3)
p_mat <- cor_pmat(corr)
ggcorrplot(corr, hc.order = TRUE, type = "lower", lab = TRUE)
ggcorrplot(corr, hc.order = TRUE, type = "lower", p.mat = p_mat)

library(ggstatsplot)

ggstatsplot::ggcorrmat(
  data = wq_data1[1:17],
  type = "nonparametric", # parametric for Pearson, nonparametric for Spearman's correlation
  colors = c("steelblue", "white", "darkred") # change default colors
)


## Self Organizing Map (Pattern)
# reference : https://www.shanelynn.ie/self-organising-maps-for-customer-segmentation-using-r/

library(kohonen)

wq_data_matrix <- as.matrix(wq_data1[1:17])

som_grid <- somgrid(xdim=10, ydim=10, topo="hexagonal")
som_model <- som(wq_data_matrix, grid=som_grid)

coolBlueHotRed <- function(n, alpha=1) {rainbow(n, end=2/3, alpha=alpha)[n:1]}

par(mfrow=c(3,2))
for (i in 1:17) {
  plot(som_model, type="property", property=getCodes(som_model)[,i], 
       main=colnames(getCodes(som_model))[i], palette.name=coolBlueHotRed)}
par(mfrow=c(1,1))


## boxplot
library(ggplot2)

ggplot(wq_data, aes(x=site, y=BOD)) +
  geom_boxplot(fill='red')
ggplot(wq_data, aes(x=site, y=COD)) +
  geom_boxplot(fill='blue')
ggplot(wq_data, aes(x=site, y=TOC)) +
  geom_boxplot(fill='green')
ggplot(wq_data, aes(x=site, y=DOC)) +
  geom_boxplot(fill='yellow')
ggplot(wq_data, aes(x=site, y=NH3_N)) +
  geom_boxplot(fill='orange')
ggplot(wq_data, aes(x=site, y=T_N)) +
  geom_boxplot(fill='brown')

## Kruskal-Wallis test
kruskal.test(BOD ~ site, data = wq_data)
kruskal.test(COD ~ site, data = wq_data)
kruskal.test(TOC ~ site, data = wq_data)
kruskal.test(DOC ~ site, data = wq_data)
kruskal.test(NH3_N ~ site, data = wq_data)
kruskal.test(T_N ~ site, data = wq_data)


## Cluster analysis
# reference1 : https://data-make.tistory.com/91
# reference2 : https://www.statmethods.net/advstats/cluster.html
# reference3 : https://rfriend.tistory.com/585

wq_cluster <- read.csv("C:/Users/User/Desktop/Clustering ���� ������_������ ���.csv",
                       sep=",", header=T)
row.names(wq_cluster) <- wq_cluster$site
wq_cluster <- wq_cluster[-1]

# Decide number of clusters 1 (NbClust)
library(NbClust)
nc <- NbClust(wq_cluster, distance="euclidean", method="ward.D",
              min.nc=1, max.nc=7)
par(mfrow=c(1,1))
plot(fit)
rect.hclust(fit, k=3)

# Decide number of clusters 2 (fviz_nbclust)
library(factoextra)
fviz_nbclust(wq_cluster, 
             FUNcluster = kmeans,
             method = c("silhouette"), diss = NULL,
             k.max = 10, nboot = 100, verbose = interactive(),
             barfill = "steelblue",
             barcolor = "steelblue",
             linecolor = "steelblue",
             print.summary = TRUE)

# Distance matrix
water_scale <- scale(water)
d <- dist(water_scale, method="euclidean")
as.matrix(d)[1:5,1:5]

# Apply Distance matrix model
## Hierarchical Cluster Analysis
# Decide number of clusters
library(factoextra)
fviz_nbclust(wq_cluster, 
             FUNcluster = hcut,
             method = c("silhouette"), diss = NULL,
             k.max = 10, nboot = 100, verbose = interactive(),
             barfill = "steelblue",
             barcolor = "steelblue",
             linecolor = "steelblue",
             print.summary = TRUE)
d <- dist(wq_cluster, method="euclidean")
fit <- hclust(d, method="ward.D")
plot(fit)
rect.hclust(fit, k=3)

## fviz_silhouette: Visualize Silhouette Information from Clustering
library(factoextra)
## K-means clustering
# Decide number of clusters
fviz_nbclust(wq_cluster, 
             FUNcluster = kmeans,
             method = c("silhouette"), diss = NULL,
             k.max = 10, nboot = 100, verbose = interactive(),
             barfill = "steelblue",
             barcolor = "steelblue",
             linecolor = "steelblue",
             print.summary = TRUE)
km.res <- kmeans(wq_cluster, centers=3)
km.res[["cluster"]]
# Visualize silhouhette information
library(cluster)
sil <- silhouette(km.res$cluster, dist(wq_cluster, method="euclidean"))
fviz_silhouette(sil)
# visualizing K-means clusters
fviz_cluster(km.res, data = wq_cluster,
             choose.vars = NULL, stand = TRUE,
             axes = c(1, 2), geom = c("point", "text"),
             repel = FALSE, show.clust.cent = TRUE,
             ellipse = TRUE, ellipse.type = "convex",
             ellipse.level = 0.95, ellipse.alpha = 0.2,
             shape = NULL, pointsize = 1.5,
             labelsize = 12, main = "Cluster plot",
             xlab = NULL, ylab = NULL,
             outlier.color = "black", outlier.shape = 19,
             outlier.pointsize = pointsize, outlier.labelsize = labelsize,
             ggtheme = theme_grey()
)

## Partitioning Around Medoids
# reference : https://www.datanovia.com/en/lessons/k-medoids-in-r-algorithm-and-practical-examples/
library(cluster)
library(factoextra)
# Decide number of clusters
fviz_nbclust(wq_cluster, 
             FUNcluster = pam,
             method = c("silhouette"), diss = NULL,
             k.max = 10, nboot = 100, verbose = interactive(),
             barfill = "steelblue",
             barcolor = "steelblue",
             linecolor = "steelblue",
             print.summary = TRUE)
pam.res <- pam(wq_cluster, k=3)
print(pam.res)
# visualizing PAM clusters
fviz_cluster(pam.res, data = wq_cluster,
             choose.vars = NULL, stand = TRUE,
             axes = c(1, 2), geom = c("point", "text"),
             repel = FALSE, show.clust.cent = TRUE,
             ellipse = TRUE, ellipse.type = "convex",
             ellipse.level = 0.95, ellipse.alpha = 0.2,
             shape = NULL, pointsize = 1.5,
             labelsize = 12, main = "Cluster plot",
             xlab = NULL, ylab = NULL,
             outlier.color = "black", outlier.shape = 19,
             outlier.pointsize = pointsize, outlier.labelsize = labelsize,
             ggtheme = theme_grey()
)

## Gaussian Mixture Model
# reference 1 : https://search.r-project.org/CRAN/refmans/ClusterR/html/GMM.html
# reference 2 : https://cran.r-project.org/web/packages/ClusterR/vignettes/the_clusterR_package.html
# Install packages
library(ClusterR)
dat <- as.matrix(wq_cluster)
dat <- center_scale(dat)
# Decide number of clusters
opt_gmm <- Optimal_Clusters_GMM(
  dat, max_clusters = 10, criterion = "AIC", 
  dist_mode = "maha_dist", seed_mode = "random_subset",
  km_iter = 10, em_iter = 10, var_floor = 1e-10, 
  plot_data = T)
opt_gmm <- Optimal_Clusters_GMM(
  dat, max_clusters = 10, criterion = "BIC", 
  dist_mode = "maha_dist", seed_mode = "random_subset",
  km_iter = 10, em_iter = 10, var_floor = 1e-10, 
  plot_data = T)
gmm <- GMM(dat, 3, dist_mode="maha_dist", seed_mode="random_subset", 
           km_iter=10, em_iter=10)
gmm[["Log_likelihood"]]

## SOM cluster
# reference : https://woosa7.github.io/R-Clustering-Kmens-SOM/

# Install packages
library(SOMbrero)
library(kohonen)

# Normalization of data
water_scale <- data.frame(scale(wq_cluster))
water_scale_matrix <- as.matrix(water_scale)

# Training the SOM model
som_grid <- somgrid(xdim=3, ydim=1, topo="hexagonal")
som_model1 <- som(water_scale_matrix, grid=som_grid)
str(som_model1)
som_model2 <- trainSOM(x.data=water_scale, dimension=c(3,1),
                       nb.save=10, maxit=2000, scaling="none",
                       radius.type="letremy")
str(som_model2)

# Visualization
plot(som_model1, main="feature distribution")
som_model1[["unit.classif"]]
table(som_model2$clustering)
plot(som_model2, what="prototypes", type="umatrix", print.title=T)
plot(som_model2, what="obs", type="names", print.title=T, scale=c(1,1))
som_model2[["clustering"]]
plot(som_model1, type="counts", main="cluster size")

# Clustering results
clusters <- superClass(model, k=5)
summary(clusters)
plot(clusters)
plot(clusters, type="dendro3d")

## Density plot with group
wq_cluster$cluster <- c(1,1,1,1,1,1,1,1,1,3,
                        1,1,1,3,2,3,2,2,2,3,
                        3,2,3,3,3,3,3,3,3,2,
                        4,4,2,4,4,4)
wq_cluster$cluster <- as.factor(wq_cluster$cluster)

library(ggplot2)
ggplot(wq_cluster, aes(x=BOD, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=COD, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=TOC, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=DOC, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=T_N, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=DTN, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=NH3_N, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=NO3_N, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=T_P, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=DTP, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=PO4_P, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=Cl_, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=d15N, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=d18O, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=HIX, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=BIX, fill=cluster)) +
  geom_density(alpha=0.4)
ggplot(wq_cluster, aes(x=FI, fill=cluster)) +
  geom_density(alpha=0.4)
