source_data <- read.csv("C:/Users/User/Desktop/R MixSIAR �м���� ����_���갭/2024 ȯ����������� ����/����н� ��� ������ �⿩�� ����/�ʿ� ������/Jiseok2024_sources_FI_raw_ML.csv",
                        sep=",", header=T)
consumer_data <- read.csv("C:/Users/User/Desktop/R MixSIAR �м���� ����_���갭/2024 ȯ����������� ����/����н� ��� ������ �⿩�� ����/�ʿ� ������/Jiseok2024_consumer_FI_ML.csv",
                          sep=",", header=T)
source_data$Source <- as.factor(source_data$Source)



# Confusion Matrix : https://zetawiki.com/wiki/R_confusionMatrix()

### Decision tree
# reference : https://woosa7.github.io/R-Classification-Decision-Tree/
# response variable : factor
library(party)
library(caret)

tree_model <- ctree(Source ~ BIX + FI, data = source_data)
tree_model
plot(tree_model)
plot(tree_model, type = "simple")
pred_tree <- predict(tree_model, newdata = consumer_data)
cm <- confusionMatrix(pred_tree, test$dominant) 
cm
cm$overall["Accuracy"]
cm$byClass["Sensitivity"]
cm$byClass["Specificity"]
cm$byClass["Specificity"]
cm$byClass["Precision"]
cm$byClass["Recall"]
mean(pred_tree != test$dominant) # misclassification rate


### Bagging
# reference : https://todayisbetterthanyesterday.tistory.com/53
library(adabag)

bag_model <- bagging(dominant ~ BOD + COD + TN + TP + TOC +
                       SS + EC + pH + DO + Temperature + Turbidity +
                       Transparency + Chla + LowWaterLevel + Inflow +
                       Discharge + Reservoir, data = train, mfinal=1000)
bag_model$importance
plot(bag_model$trees[[10]])
text(bag_model$trees[[10]])

pred_bag <- as.factor(predict(bag_model, newdata=test)$class)
cm <- confusionMatrix(pred_bag, test$dominant) 
cm
cm$overall["Accuracy"]
cm$byClass["Sensitivity"]
cm$byClass["Specificity"]
cm$byClass["Specificity"]
cm$byClass["Precision"]
cm$byClass["Recall"]
mean(pred_bag != test$dominant) # misclassification rate


### AdaBoost
# reference : https://todayisbetterthanyesterday.tistory.com/53
library(adabag)

ada_model <- boosting(dominant ~ BOD + COD + TN + TP + TOC +
                        SS + EC + pH + DO + Temperature + Turbidity +
                        Transparency + Chla + LowWaterLevel + Inflow +
                        Discharge + Reservoir, data = train, boos=TRUE, mfinal=1000)
ada_model$importance
plot(ada_model$trees[[10]])
text(ada_model$trees[[10]])

pred_ada <- as.factor(predict(ada_model, newdata=test)$class)
cm <- confusionMatrix(pred_ada, test$dominant)
cm
cm$overall["Accuracy"]
cm$byClass["Sensitivity"]
cm$byClass["Specificity"]
cm$byClass["Specificity"]
cm$byClass["Precision"]
cm$byClass["Recall"]
mean(pred_ada != test$dominant) # misclassification rate


### Random Forest
# reference : https://data-make.tistory.com/81
library(randomForest)

RandomForest_T2 <- randomForest(dominant ~ BOD + COD + TN + TP + TOC +
                                  SS + EC + pH + DO + Temperature + Turbidity +
                                  Transparency + Chla + LowWaterLevel + Inflow +
                                  Discharge + Reservoir, data = train,
                                ntree = 1000)
RandomForest_T2
RandomForest_T2$predict
RandomForest_T2$importance
layout(matrix(c(1,2),nrow=1),width=c(4,1)) 

par(mar=c(5,4,4,7)) 
plot(RandomForest_T2)
par(mar=c(5,4,4,1),new=T) 
plot(c(0,1),type="n", axes=F, xlab="", ylab="")
legend("topright", colnames(RandomForest_T2$err.rate),col=1:5,cex=0.8,fill=1:5)
par(mar=c(5,4,4,2))

pred_forest <- predict(RandomForest_T2, newdata = test, type = 'class')
cm <- confusionMatrix(pred_forest, test$dominant)
cm
cm$overall["Accuracy"]
cm$byClass["Sensitivity"]
cm$byClass["Specificity"]
cm$byClass["Specificity"]
cm$byClass["Precision"]
cm$byClass["Recall"]
mean(pred_forest != test$dominant) # misclassification rate


### Support Vector Machine
# reference : https://blog.naver.com/PostView.nhn?blogId=pmw9440&logNo=221586667065
# reference : https://ratsgo.github.io/machine%20learning/2017/05/23/SVM/
library(e1071)
svm_model <- svm(dominant ~ BOD + COD + TN + TP + TOC +
                   SS + EC + pH + DO + Temperature + Turbidity +
                   Transparency + Chla + LowWaterLevel + Inflow +
                   Discharge + Reservoir, data = train,  
                 type = "C-classification", kernel = "radial")
summary(svm_model)
pred_svm <- predict(svm_model, newdata = test)

cm <- confusionMatrix(pred_svm, test$dominant) 
cm
cm$overall["Accuracy"]
cm$byClass["Sensitivity"]
cm$byClass["Specificity"]
cm$byClass["Specificity"]
cm$byClass["Precision"]
cm$byClass["Recall"]
mean(pred_svm != test$dominant) # misclassification rate